const mongoose = require('mongoose');

const pacientSchema = new mongoose.Schema({
  dni: {type: String, unique: true },
  nom: String,
  cognoms: String,
  sexe: String,
  diagnosi: String,
});

module.exports = mongoose.model('Pacient', pacientSchema);
