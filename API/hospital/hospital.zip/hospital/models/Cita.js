const mongoose = require('mongoose');

const citaSchema = new mongoose.Schema({
  data: { type: Date, required: true },
  pacient: { type: mongoose.Schema.Types.ObjectId, ref: 'Pacient', required: true },
  metge: { type: mongoose.Schema.Types.ObjectId, ref: 'Metge', required: true },
  motiu: String,
});

module.exports = mongoose.model('Cita', citaSchema);
