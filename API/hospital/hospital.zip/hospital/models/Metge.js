const mongoose = require('mongoose');

const metgeSchema = new mongoose.Schema({
  dni: {type: String, unique: true },
  dni: String,
  nom: String,
  especialitat: String,
});

module.exports = mongoose.model('Metge', metgeSchema);
