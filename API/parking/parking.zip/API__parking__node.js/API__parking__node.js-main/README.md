# Parking

.env
```
MONGODB_URI=mongodb://localhost:27017
PORT=3000
```


models/cotxe.js
```
const mongoose = require('mongoose');

const cotxeSchema = new mongoose.Schema({
    matricula: { type: String, required: true, unique: true },
    marca: { type: String, required: true },
    model: { type: String, required: true },
    color: { type: String, required: true },
    entrada: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Cotxe', cotxeSchema);
```


rutes/rutesParking.js
```
const express = require('express');
const Cotxe = require('../models/cotxe');

const router = express.Router();

router.post('/crea', async (req, res) => {
    try {
        const nouCotxe = new Cotxe(req.body);
        await nouCotxe.save();
        res.status(201).json(nouCotxe);
    } 
    catch (error) {
        res.status(400).json({ missatge: error.message });
    }
});

router.get('/cotxes', async (req, res) => {
    try {
        // el mètode .find() sense paràmetres obté tots els cotxes
        const cotxes = await Cotxe.find();
        res.json(cotxes);
    } 
    catch (error) {
        res.status(500).json({ missatge: error.message });
    }
});

router.get('/cotxe/:matricula', async (req, res) => {
    try {
        const cotxe = await Cotxe.findOne({ matricula: req.params.matricula });
        if (cotxe) res.json(cotxe);
        else res.status(404).json({ missatge: 'Cotxe no trobat' });
    } 
    catch (error) {
        res.status(500).json({ missatge: error.message });
    }
});

router.put('/modifica/:matricula', async (req, res) => {
    try {
        const cotxe = await Cotxe.findOneAndUpdate(
            { matricula: req.params.matricula },
            req.body,
            { new: true }
        );
        if (cotxe) res.json(cotxe);
        else res.status(404).json({ missatge: 'Cotxe no trobat' });
    } 
    catch (error) {
        res.status(400).json({ missatge: error.message });
    }
});

router.delete('/esborra/:matricula', async (req, res) => {
    try {
        const cotxe = await Cotxe.findOneAndDelete({ matricula: req.params.matricula });
        if (cotxe) res.json({ missatge: 'Cotxe eliminat' });
        else res.status(404).json({ missatge: 'Cotxe no trobat' });
    } 
    catch (error) {
        res.status(500).json({ missatge: error.message });
    }
});

module.exports = router;
```


servidor.js
```
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const rutesParking = require('./rutes/rutesParking');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json()); 

mongoose.connect('mongodb://localhost:27017/parking')
    .then(() => {
        console.log('Connexió a MongoDB establerta');
    })
    .catch((error) => {
        console.error('Error de connexió a MongoDB:', error);
    }
);

app.use('/parking', rutesParking); 

app.listen(port, () => {
    console.log(`Servidor actiu a http://localhost:${port}`);
});
```

